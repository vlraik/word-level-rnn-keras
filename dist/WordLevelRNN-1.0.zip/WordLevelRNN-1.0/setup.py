from distutils.core import setup

setup(
    name='WordLevelRNN',
    version='1.0',
    packages=['wordlevelrnn',],
    license='	',
    long_description=open('README.md').read(),
)
